select last_name, department_id fromemployees 
where department_id = 20 or department_id = 50 order by last_name;